BMW E46 RED EDITION – APLIKACJA MOBILNA
======================================

ZAWARTOŚĆ
- www/: aplikacja PWA (Android + iPhone), działa offline po pierwszym załadowaniu.
- package.json + capacitor.config.json: konfiguracja opakowania tej samej aplikacji jako Android APK / iOS.
- assets/: grafiki i zdjęcia przekazane w archiwum.

CO DZIAŁA
- Pulpit projektu i pasek nawigacji.
- Plan OEM+ z checkboxami i automatycznym postępem.
- Dziennik serwisowy (data, przebieg, koszt, opis).
- Notatki.
- Baza techniczna N46B20 i lista diagnostyczna.
- Galeria z powiększaniem zdjęć.
- Eksport/import danych JSON.
- Lokalny zapis wpisów w pamięci przeglądarki/aplikacji.

INSTALACJA PWA
1. Umieść zawartość folderu www na hostingu HTTPS.
2. Android: otwórz adres w Chrome i wybierz „Zainstaluj aplikację” / „Dodaj do ekranu głównego”.
3. iPhone: otwórz adres w Safari, wybierz Udostępnij → Dodaj do ekranu początkowego.

BUDOWANIE APK (wymaga komputera, Android Studio i Android SDK)
1. Zainstaluj Node.js LTS i Android Studio.
2. W katalogu projektu uruchom: npm install
3. Uruchom: npx cap add android
4. Uruchom: npx cap sync android
5. Uruchom: npx cap open android
6. W Android Studio wybierz Build → Build Bundle(s) / APK(s) → Build APK(s).
   Plik APK znajdziesz zwykle w android/app/build/outputs/apk/debug/app-debug.apk.

IOS
Do zbudowania natywnej aplikacji iOS potrzebny jest macOS z Xcode oraz konto Apple Developer do dystrybucji. Sama PWA może być dodana do ekranu początkowego iPhone'a bez kompilowania IPA.

WAŻNE O DANYCH
Dane są przechowywane lokalnie na danym urządzeniu. Nie synchronizują się automatycznie między telefonami. Używaj Eksportu JSON i Importu JSON, aby przenosić kopię danych.

UWAGA O ŹRÓDLE
Przesłany RAR zawierał dokumentację i grafiki, ale nie zawierał kodu źródłowego oryginalnej strony. Ta aplikacja jest odtworzonym mobilnym projektem na podstawie dostarczonej dokumentacji i zawartości strony, a nie automatyczną konwersją oryginalnego kodu.


WERSJA 2.3: baza aplikacji zachowuje funkcje wersji 2.0 (edycja danych auta, zadania własne, galeria zdjęć, serwis, notatki, kopie zapasowe) oraz dodaje model 3D garażu z trybem aktualnym/docelowym. Model jest koncepcyjny, nie jest skanem 3D.


BMW RED EDITION 2.4 — aktualizacja na bazie 2.3.1
- Zachowano istniejące moduły planu, serwisu, techniki, danych auta i galerii.
- Ulepszono proceduralny model E46 Coupe w car3d.js.
- Obrót i zoom obsługiwane przez OrbitControls.
- Zmiany czarnych nerek, felg, Angel Eyes i zacisków są powiązane z ukończeniem zadań bazowych wyglądu.
- Model nadal jest koncepcyjną geometrią 3D, nie skanem 1:1 konkretnego egzemplarza.
