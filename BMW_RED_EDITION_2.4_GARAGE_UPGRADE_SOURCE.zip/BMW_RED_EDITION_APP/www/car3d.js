import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const host = document.getElementById('car3d');
if (host) {
  try {
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x101216);

    const camera = new THREE.PerspectiveCamera(36, 1, 0.1, 100);
    camera.position.set(5.8, 3.4, 7.4);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.18;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    host.replaceChildren(renderer.domElement);

    scene.add(new THREE.HemisphereLight(0xcbd8ee, 0x17191e, 2.15));
    const key = new THREE.DirectionalLight(0xffffff, 3.4);
    key.position.set(4, 7, 6); key.castShadow = true; scene.add(key);
    const redRim = new THREE.DirectionalLight(0xff2438, 2.2);
    redRim.position.set(-5, 3, -4); scene.add(redRim);
    const soft = new THREE.DirectionalLight(0x9eb8df, 1.15);
    soft.position.set(-4, 3, 5); scene.add(soft);

    const floor = new THREE.Mesh(
      new THREE.CircleGeometry(8, 80),
      new THREE.MeshStandardMaterial({ color: 0x17191d, roughness: .34, metalness: .28 })
    );
    floor.rotation.x = -Math.PI / 2; floor.position.y = -.04; floor.receiveShadow = true; scene.add(floor);
    const platform = new THREE.Mesh(
      new THREE.TorusGeometry(3.05, .025, 8, 120),
      new THREE.MeshBasicMaterial({ color: 0xd51d2c })
    );
    platform.rotation.x = Math.PI / 2; platform.position.y = .005; platform.scale.set(1.12, .68, 1); scene.add(platform);

    const car = new THREE.Group(); scene.add(car);
    const paint = new THREE.MeshPhysicalMaterial({ color: 0x34383f, metalness: .84, roughness: .22, clearcoat: 1, clearcoatRoughness: .12 });
    const glass = new THREE.MeshPhysicalMaterial({ color: 0x101820, metalness: .22, roughness: .12, transparent: true, opacity: .82 });
    const black = new THREE.MeshStandardMaterial({ color: 0x08090b, metalness: .42, roughness: .26 });
    const chrome = new THREE.MeshStandardMaterial({ color: 0xb9c0c8, metalness: .92, roughness: .2 });
    const tireMat = new THREE.MeshStandardMaterial({ color: 0x090a0c, roughness: .9 });
    const silver = new THREE.MeshStandardMaterial({ color: 0xaeb5bd, metalness: .9, roughness: .23 });
    const red = new THREE.MeshStandardMaterial({ color: 0xb50d20, metalness: .35, roughness: .28 });
    const headMat = new THREE.MeshStandardMaterial({ color: 0xe9e5dc, emissive: 0x54422b, emissiveIntensity: .5 });
    const tailMat = new THREE.MeshStandardMaterial({ color: 0x9d1020, emissive: 0x4d0008, emissiveIntensity: .8 });

    function addBox(parent, w, h, d, mat, x, y, z, bevel = false) {
      const geometry = new THREE.BoxGeometry(w, h, d);
      const obj = new THREE.Mesh(geometry, mat);
      obj.position.set(x, y, z); obj.castShadow = true; obj.receiveShadow = true;
      parent.add(obj); return obj;
    }
    function addMesh(geometry, mat, x, y, z, parent = car) {
      const obj = new THREE.Mesh(geometry, mat);
      obj.position.set(x, y, z); obj.castShadow = true; obj.receiveShadow = true; parent.add(obj); return obj;
    }

    // E46 coupe silhouette: front faces +Z, long bonnet, short rear deck.
    addBox(car, 1.82, .48, 4.08, paint, 0, .12, -.02);
    addBox(car, 1.88, .30, 1.30, paint, 0, .31, 1.45);
    addBox(car, 1.84, .28, .92, paint, 0, .30, -1.58);
    const hood = addBox(car, 1.78, .105, 1.48, paint, 0, .48, 1.23); hood.rotation.x = -.025;
    const trunk = addBox(car, 1.76, .11, .82, paint, 0, .46, -1.69); trunk.rotation.x = .025;

    // Sloped roof and cabin glazing.
    const roof = addBox(car, 1.48, .16, 1.58, paint, 0, 1.18, -.12); roof.rotation.x = -.035;
    const cabin = addBox(car, 1.60, .68, 2.05, paint, 0, .91, -.12);
    cabin.scale.set(1, .92, 1);
    // Dark side windows, split into front and rear coupe panes.
    for (const side of [-1, 1]) {
      const x = side * .813;
      addBox(car, .025, .42, .88, glass, x, 1.00, .34);
      addBox(car, .025, .40, .55, glass, x, 1.00, -.52);
      addBox(car, .035, .52, .035, chrome, side * .824, 1.00, -.12);
      addBox(car, .035, .035, 1.55, chrome, side * .82, .72, -.12);
      addBox(car, .18, .12, .24, paint, side * .96, .79, .88);
      addBox(car, .20, .07, .12, black, side * .98, .79, 1.00);
      addBox(car, .035, .05, .22, chrome, side * .925, .48, -.35);
      // side crease
      addBox(car, .022, .022, 2.55, chrome, side * .925, .22, -.05);
    }
    const windshield = addBox(car, 1.46, .035, .70, glass, 0, .99, .86); windshield.rotation.x = -.58;
    const rearGlass = addBox(car, 1.40, .035, .66, glass, 0, .99, -.98); rearGlass.rotation.x = .58;

    // Front and rear bumpers, lower air intake and kidney grilles.
    addBox(car, 1.90, .28, .25, paint, 0, .02, 2.06);
    addBox(car, 1.48, .17, .07, black, 0, -.12, 2.20);
    addBox(car, 1.90, .27, .24, paint, 0, .02, -2.08);
    const grilleParts = [];
    for (const x of [-.235, .235]) {
      const frame = addBox(car, .34, .31, .075, chrome, x, .43, 2.095);
      const inner = addBox(car, .285, .26, .08, black, x, .43, 2.105);
      grilleParts.push(frame, inner);
      for (let i = -2; i <= 2; i++) addBox(car, .018, .23, .085, chrome, x + i * .048, .43, 2.15);
    }
    const headlamps = [];
    for (const x of [-.68, .68]) {
      addBox(car, .48, .23, .075, headMat, x, .44, 2.10);
      for (let j = 0; j < 2; j++) {
        const ring = addMesh(new THREE.TorusGeometry(.075, .014, 8, 28), headMat, x + (j - .5) * .17, .445, 2.155);
        ring.rotation.y = 0; ring.userData.kind = 'angel'; headlamps.push(ring);
      }
      addBox(car, .35, .20, .07, tailMat, x, .42, -2.13);
      addBox(car, .17, .12, .07, headMat, x * 1.12, .41, 2.13);
      addBox(car, .16, .12, .08, black, x, -.20, 2.19);
    }
    // Rear number plate panel and exhaust tips.
    addBox(car, .72, .17, .035, chrome, 0, .37, -2.205);
    for (const x of [-.52, .52]) {
      const exhaust = addMesh(new THREE.CylinderGeometry(.075, .075, .22, 20), chrome, x, -.22, -2.18);
      exhaust.rotation.x = Math.PI / 2;
    }

    const wheelParts = [];
    function makeWheel(x, z) {
      const group = new THREE.Group(); group.position.set(x, -.12, z); car.add(group);
      const tire = new THREE.Mesh(new THREE.CylinderGeometry(.49, .49, .27, 48), tireMat);
      tire.rotation.z = Math.PI / 2; tire.castShadow = true; group.add(tire);
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(.355, .355, .285, 40), silver);
      rim.rotation.z = Math.PI / 2; group.add(rim);
      const spokes = [];
      for (let i = 0; i < 5; i++) {
        const a = i * Math.PI * 2 / 5;
        const spoke = addBox(group, .055, .055, .33, silver, 0, Math.sin(a) * .17, Math.cos(a) * .17);
        spoke.rotation.x = -a; spokes.push(spoke);
      }
      const hub = new THREE.Mesh(new THREE.CylinderGeometry(.095, .095, .30, 24), chrome);
      hub.rotation.z = Math.PI / 2; group.add(hub);
      const caliper = addBox(group, .10, .25, .15, chrome, x > 0 ? -.08 : .08, .03, .30);
      wheelParts.push({ rim, spokes, caliper });
    }
    for (const x of [-.92, .92]) for (const z of [-1.30, 1.30]) makeWheel(x, z);

    // Roof/boot details and subtle floor glow.
    addBox(car, .32, .035, .06, black, 0, 1.29, -1.70);
    const glow = new THREE.PointLight(0xb90e25, 1.4, 5); glow.position.set(0, .25, -2.7); scene.add(glow);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true; controls.dampingFactor = .065;
    controls.minDistance = 3.8; controls.maxDistance = 11.5;
    controls.target.set(0, .48, 0); controls.maxPolarAngle = Math.PI / 2.02;

    let mode = 'current';
    let completed = {};
    try { completed = JSON.parse(localStorage.getItem('bmw-red-edition-v2') || '{}').done || {}; } catch (_) {}

    function applyBuild() {
      const target = mode === 'target';
      const blackGrille = target || !!completed['base-1-0'];
      const blackWheels = target || !!completed['base-1-1'];
      const angelEyes = target || !!completed['base-1-2'];
      const redCalipers = target || !!completed['base-1-3'];
      grilleParts.forEach((part, index) => {
        if (part.material === chrome || part.material === black) part.material = blackGrille ? black : chrome;
      });
      wheelParts.forEach(w => {
        w.rim.material = blackWheels ? black : silver;
        w.spokes.forEach(s => s.material = blackWheels ? black : silver);
        w.caliper.material = redCalipers ? red : chrome;
      });
      headlamps.forEach(ring => {
        ring.visible = angelEyes;
        ring.material = angelEyes
          ? new THREE.MeshStandardMaterial({ color: 0xffd49a, emissive: 0xff9e36, emissiveIntensity: 1.65 })
          : headMat;
      });
      paint.color.set(target ? 0x252a31 : 0x34383f);
    }

    window.updateCar3D = (done) => { completed = done || {}; applyBuild(); };
    document.querySelectorAll('[data-model-mode]').forEach(button => {
      button.addEventListener('click', () => {
        mode = button.dataset.modelMode;
        document.querySelectorAll('[data-model-mode]').forEach(b => b.classList.toggle('active', b === button));
        applyBuild();
      });
    });
    document.getElementById('reset3d')?.addEventListener('click', () => {
      camera.position.set(5.8, 3.4, 7.4); controls.target.set(0, .48, 0); controls.update();
    });

    function resize() {
      const width = Math.max(1, host.clientWidth), height = Math.max(1, host.clientHeight);
      renderer.setSize(width, height, false); camera.aspect = width / height; camera.updateProjectionMatrix();
    }
    if ('ResizeObserver' in window) new ResizeObserver(resize).observe(host);
    else window.addEventListener('resize', resize);
    resize(); applyBuild();

    function animate() { requestAnimationFrame(animate); controls.update(); renderer.render(scene, camera); }
    animate();
  } catch (error) {
    console.error('BMW RED EDITION 3D error:', error);
    host.innerHTML = '<div style="padding:24px;color:#d5d7dc;text-align:center;font-size:13px">Nie udało się uruchomić modelu 3D. Sprawdź połączenie z internetem i obsługę WebGL.</div>';
  }
}
