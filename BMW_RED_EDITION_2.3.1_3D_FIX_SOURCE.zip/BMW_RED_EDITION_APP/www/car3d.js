import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/controls/OrbitControls.js';

const host=document.getElementById('car3d');
window.addEventListener('error', (event) => {
  if (host && !host.querySelector('canvas')) {
    host.innerHTML = '<div style="padding:24px;color:#d5d7dc;text-align:center;font-size:13px">Nie udało się załadować biblioteki 3D. Sprawdź połączenie z internetem i uruchom ponownie aplikację.</div>';
  }
});
if(host){
 const scene=new THREE.Scene(); scene.background=new THREE.Color(0x111317);
 const camera=new THREE.PerspectiveCamera(38,1,.1,100); camera.position.set(5.2,3.1,6.5);
 const renderer=new THREE.WebGLRenderer({antialias:true,alpha:false}); renderer.setPixelRatio(Math.min(devicePixelRatio,2)); renderer.outputColorSpace=THREE.SRGBColorSpace; renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.15; host.appendChild(renderer.domElement);
 scene.add(new THREE.HemisphereLight(0xcbd8ee,0x25252a,2));
 const key=new THREE.DirectionalLight(0xffffff,3.2);key.position.set(4,7,5);scene.add(key);
 const rimLight=new THREE.DirectionalLight(0xff2438,2.1);rimLight.position.set(-5,3,-4);scene.add(rimLight);
 const floor=new THREE.Mesh(new THREE.PlaneGeometry(200,200),new THREE.MeshStandardMaterial({color:0x17191d,roughness:.35,metalness:.25}));floor.rotation.x=-Math.PI/2;floor.position.y=-.72;scene.add(floor);
 const car=new THREE.Group();scene.add(car);
 const paint=new THREE.MeshPhysicalMaterial({color:0x34383e,metalness:.82,roughness:.23,clearcoat:1,clearcoatRoughness:.12});
 const glass=new THREE.MeshPhysicalMaterial({color:0x101a22,metalness:.35,roughness:.12,transparent:true,opacity:.88});
 const black=new THREE.MeshStandardMaterial({color:0x08090b,metalness:.35,roughness:.28});
 const chrome=new THREE.MeshStandardMaterial({color:0xb8bec5,metalness:.9,roughness:.2});
 const red=new THREE.MeshStandardMaterial({color:0xb80f20,metalness:.35,roughness:.3});
 const lamp=new THREE.MeshStandardMaterial({color:0xf2e8d4,emissive:0xffd59a,emissiveIntensity:.45});
 const tire=new THREE.MeshStandardMaterial({color:0x090a0b,roughness:.88});
 const silver=new THREE.MeshStandardMaterial({color:0x9da3a9,metalness:.88,roughness:.24});
 function box(parent,w,h,d,mat,x,y,z,bevel=0){let geo=new THREE.BoxGeometry(w,h,d);let m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);parent.add(m);return m}
 function wheel(x,z){const g=new THREE.Group();g.position.set(x,-.27,z);car.add(g);
  const tyre=new THREE.Mesh(new THREE.CylinderGeometry(.48,.48,.27,40),tire);tyre.rotation.z=Math.PI/2;g.add(tyre);
  const rim=new THREE.Mesh(new THREE.CylinderGeometry(.34,.34,.285,32),silver);rim.rotation.z=Math.PI/2;g.add(rim);
  const hub=new THREE.Mesh(new THREE.CylinderGeometry(.09,.09,.30,24),chrome);hub.rotation.z=Math.PI/2;g.add(hub);
  for(let i=0;i<5;i++){const a=i*Math.PI*2/5;const spoke=box(g,.055,.56,.035,silver,0,Math.cos(a)*.01,0);spoke.position.set(0,Math.sin(a)*.19,Math.cos(a)*.19);spoke.rotation.x=a;}
  const cal=box(g,.10,.26,.12,red,x>0?-.12:.12,0,.23);cal.name='caliper';return g;
 }
 // coupe body: long low silhouette, front points toward +Z
 box(car,1.82,.48,4.05,paint,0,-.10,0);
 box(car,1.9,.34,1.05,paint,0,.22,1.52);
 box(car,1.88,.30,.85,paint,0,.22,-1.55);
 // hood and trunk surfaces
 box(car,1.78,.12,1.42,paint,0,.18,1.20);
 box(car,1.78,.12,.85,paint,0,.18,-1.62);
 // cabin with sloped windshield/rear glass and roof
 const roof=box(car,1.48,.16,1.75,paint,0,.75,-.12);roof.rotation.x=-.03;
 const cabin=box(car,1.58,.57,2.0,paint,0,.52,-.12);cabin.scale.set(1,.92,1);
 const sideWinL=box(car,.025,.43,1.48,glass,-.797,.56,-.10);sideWinL.rotation.x=0;
 const sideWinR=box(car,.025,.43,1.48,glass,.797,.56,-.10);
 // windshield / rear glass
 const wind=box(car,1.42,.48,.035,glass,0,.54,.88);wind.rotation.x=-.42;
 const rearGlass=box(car,1.4,.43,.035,glass,0,.55,-1.10);rearGlass.rotation.x=.48;
 // beltline chrome trim
 box(car,1.91,.025,2.65,chrome,0,.28,-.05);
 // front kidney grilles
 const grilleL=box(car,.36,.25,.045,black,-.24,.02,2.035);
 const grilleR=box(car,.36,.25,.045,black,.24,.02,2.035);
 // front lamps and fogs
 for(const x of [-.66,.66]){box(car,.43,.20,.06,lamp,x,.06,2.04);box(car,.23,.10,.06,black,x,.06,2.08)}
 box(car,1.45,.22,.12,paint,0,-.37,2.02);
 box(car,1.1,.12,.05,black,0,-.34,2.09);
 // rear lamps and bumpers
 for(const x of [-.70,.70])box(car,.32,.20,.055,red,x,.02,-2.04);
 box(car,1.5,.22,.12,paint,0,-.36,-2.02);
 // side mirrors, handles, front side markers
 for(const x of [-.88,.88]){box(car,.16,.12,.22,black,x,.48,.77);box(car,.10,.06,.15,chrome,x,.30,-.18);box(car,.07,.10,.05,lamp,x,.13,1.03)}
 const wheels=[wheel(-.91,1.25),wheel(.91,1.25),wheel(-.91,-1.30),wheel(.91,-1.30)];
 // twin exhausts
 for(const x of [-.48,.48]){const ex=new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,.20,20),chrome);ex.rotation.x=Math.PI/2;ex.position.set(x,-.43,-2.08);car.add(ex)}
 const angelRings=[];
 for(const x of [-.66,.66]){for(let j=0;j<2;j++){const ring=new THREE.Mesh(new THREE.TorusGeometry(.067,.012,8,24),lamp);ring.position.set(x+(j-.5)*.16,.06,2.085);ring.name='angel';car.add(ring);angelRings.push(ring)}}
 const controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.07;controls.minDistance=3.8;controls.maxDistance=11;controls.target.set(0,.05,0);controls.maxPolarAngle=Math.PI/2.03;
 function resize(){const w=host.clientWidth,h=host.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}new ResizeObserver(resize).observe(host);resize();
 let mode='current',done={};try{done=JSON.parse(localStorage.getItem('bmw-red-edition-v2')||'{}').done||{}}catch(e){}
 function apply(){const target=mode==='target';const blackGrille=target||!!done['base-1-0'];const blackWheels=target||!!done['base-1-1'];const angel=target||!!done['base-1-2'];const redCal=target||!!done['base-1-3'];
  grilleL.material=blackGrille?black:chrome;grilleR.material=blackGrille?black:chrome;
  wheels.forEach(w=>{w.children[1].material=blackWheels?black:silver;const c=w.children.find(o=>o.name==='caliper');c.material=redCal?red:chrome});
  angelRings.forEach(r=>{r.visible=angel;r.material=angel?new THREE.MeshStandardMaterial({color:0xffc45c,emissive:0xffa21c,emissiveIntensity:2}):lamp});
 }
 window.updateCar3D=(d)=>{done=d||{};apply()};
 document.querySelectorAll('[data-model-mode]').forEach(b=>b.addEventListener('click',()=>{mode=b.dataset.modelMode;document.querySelectorAll('[data-model-mode]').forEach(x=>x.classList.toggle('active',x===b));apply()}));
 document.getElementById('reset3d')?.addEventListener('click',()=>{camera.position.set(5.2,3.1,6.5);controls.target.set(0,.05,0);controls.update()});
 function animate(){requestAnimationFrame(animate);controls.update();renderer.render(scene,camera)}animate();
}
